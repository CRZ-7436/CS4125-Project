package com.ExtVision.RentalSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Cs4125ProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
