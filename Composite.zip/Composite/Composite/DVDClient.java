package Composite;

public class DVDClient {
    public static void main(String[] args) {
        DVDComponent horrorDVDs = new DVDComposite("Horror DVDs");
        DVDComponent comedyDVDs = new DVDComposite("Comedy DVDs");

        DVDComponent dvd1 = new DVDLeaf("Horror Movie 1");
        DVDComponent dvd2 = new DVDLeaf("Horror Movie 2");
        DVDComponent dvd3 = new DVDLeaf("Comedy Movie 1");

        horrorDVDs.add(dvd1);
        horrorDVDs.add(dvd2);
        comedyDVDs.add(dvd3);

        // Displaying DVDs
        horrorDVDs.displayDVDInfo();
        comedyDVDs.displayDVDInfo();
    }
}
