package com.ExtVision.RentalSystem.Composite;

import java.util.ArrayList;
import java.util.List;

public class DVDComposite extends DVDComponent {
    private List<DVDComponent> dvdComponents = new ArrayList<>();
    private String title;

    public DVDComposite(String title) {
        this.title = title;
    }

    @Override
    public void add(DVDComponent dvdComponent) {
        dvdComponents.add(dvdComponent);
    }

    @Override
    public void remove(DVDComponent dvdComponent) {
        dvdComponents.remove(dvdComponent);
    }

    @Override
    public DVDComponent getChild(int i) {
        return dvdComponents.get(i);
    }

    @Override
    public String getTitle() {
        return title;
    }

    // Method to display DVD information
    public void displayDVDInfo() {
        System.out.println(getTitle());
        for (DVDComponent dvdComponent : dvdComponents) {
            dvdComponent.displayDVDInfo();
        }
    }
}
