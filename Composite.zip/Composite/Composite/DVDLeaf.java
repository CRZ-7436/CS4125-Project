package com.ExtVision.RentalSystem.Composite;

public class DVDLeaf extends DVDComponent {
    private String title;

    public DVDLeaf(String title) {
        this.title = title;
    }

    @Override
    public String getTitle() {
        return title;
    }

}
