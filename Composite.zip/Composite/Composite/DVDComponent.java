package com.ExtVision.RentalSystem.Composite;

public abstract class DVDComponent {
    public void add(DVDComponent dvdComponent) {
        throw new UnsupportedOperationException();
    }

    public void remove(DVDComponent dvdComponent) {
        throw new UnsupportedOperationException();
    }

    public DVDComponent getChild(int i) {
        throw new UnsupportedOperationException();
    }

    public String getTitle() {
        throw new UnsupportedOperationException();
    }

}