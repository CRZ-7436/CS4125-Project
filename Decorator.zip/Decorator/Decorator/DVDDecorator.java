package com.ExtVision.RentalSystem.Decorator;

public abstract class DVDDecorator implements DVDComponent {
    protected DVDComponent decoratedDVD;

    public DVDDecorator(DVDComponent dvd) {
        this.decoratedDVD = dvd;
    }

    @Override
    public void play() {
        decoratedDVD.play();
    }

}