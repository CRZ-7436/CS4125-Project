package com.ExtVision.RentalSystem.Decorator;

public class SpecialEditionDVD extends DVDDecorator {
    private String title;
    public SpecialEditionDVD(DVDComponent dvd) {
        super(dvd);
    }

    @Override
    public void play() {
        super.play();
        addSpecialEditionFeatures();
    }

    private void addSpecialEditionFeatures() {
        System.out.println("Including special edition features for " + title);
    }
}
