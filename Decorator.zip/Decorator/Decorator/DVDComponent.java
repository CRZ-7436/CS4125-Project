package com.ExtVision.RentalSystem.Decorator;

public interface DVDComponent {
    String getTitle();
    double getPrice();
    String getDescription();
}

public class DVDComponent {
    void play();
}
