package com.ExtVision.RentalSystem.Decorator;

public class DiscountedDVD extends DVDDecorator {
    private DVDComponent decoratedDVD;
    private double discount;
    private String title;
    public DiscountedDVD(DVDComponent dvd) {
        super(dvd);
    }

    @Override
    /*
    @Override
    public String getTitle() {
        return decoratedDVD.getTitle();
    }

    @Override
    public double getPrice() {
        return decoratedDVD.getPrice() * (1 - discount);
    }

    @Override
    public String getDescription() {
        return decoratedDVD.getDescription() + " (Discounted)";
    } */
    public void play() {
        super.play();
        applyDiscount();
    }

    private void applyDiscount() {
        System.out.println("Applying discount to " + title);
    }
}