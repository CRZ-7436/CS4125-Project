package com.ExtVision.RentalSystem.Decorator;

public class BasicDVD implements DVDComponent {
    private String title;
    private double price;
    private String description;

    public BasicDVD(String title, double price, String description) {
        this.title = title;
        this.price = price;
        this.description = description;
    }

    @Override
    /*
    @Override
    public String getTitle() {
        return title;
    }

    @Override
    public double getPrice() {
        return price;
    }

    @Override
    public String getDescription() {
        return description;
    } */
    public void play() {
        System.out.println("Playing the basic version of " + title);
    }

}
